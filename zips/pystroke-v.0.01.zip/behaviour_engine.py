from behaviour import *

class BehaviourEngine:
    def __init__(self, beh_dict={}):
        self.beh_dict = beh_dict
        
    def update(self):
        pass
                    