from vector2 import Vector2
import math
from random import randint

class Behaviour:
    
    def __init__(self, name):
        self.name = name
    
    def process(self):
        pass